number_of_pies=3
pie=3.1415926
diameter_of_pie=10
print ("we have ", number_of_pies, "pies")
print ("we have ", number_of_pies, "pies", diameter_of_pie, "inches in diameter")
area_of_pie =pie*(diameter_of_pie/2)**2
print ("we have ", number_of_pies, "pies", "%10.0f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%10.1f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%10.2f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%10.3f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%10.4f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%5.4f"% area_of_pie, "square inches in area")
print ("we have ", number_of_pies, "pies", "%f"% area_of_pie, "square inches in area")

