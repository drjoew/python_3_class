big_integer= 10000000000000000000000000000000000000000000000000000000000
print("big integer is ",big_integer)
print(" ")
big_integer_plus_one = big_integer+1
print("big integer +1 is ", big_integer_plus_one)
print(" ")
big_float=10**3000
print("big float is ",big_float)
#print("big float in exponential notation is ", "%10.0E"% big_float)


