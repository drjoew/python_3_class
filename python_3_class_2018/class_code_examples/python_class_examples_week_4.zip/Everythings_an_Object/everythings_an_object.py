#!/bin/python3

print("Everything's an Object\n")

i = 2
print("i = %d" % (i))
print("Type(i) = %s" % (type(2)))           # Either i or 2 is okay
print("dir(i) = %s" % (dir(2)))             # Either i or 2 is okay
# Must use i here
print("i.__neg__() = %d (expect 2)" % (i))
print("i.__neg__() = %d (expect -2)" % ( i.__neg__() ))

"""
Yes, I'm using the tripel quotes as a way to comment out a block

# 2 won't work, must use a variable
# Since this error occurrs before the program begin, none of the print
# Statments will work, So this section is commented out
try:
    print("2.__neg__() = %d (expect -2)" % ( 2.__neg__() ))
except SyntaxError :
    # You can't catch syntax errors since it occurs before the code actually
    # runs
    print("Oops, Didn't like 2.__neg__()")
#
"""
