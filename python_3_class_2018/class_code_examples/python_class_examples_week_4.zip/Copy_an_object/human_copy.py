#!/bin/python3

# Need this to make a copy of an object
import copy

class Human(object):
    """Create a Simple human class"""

    def __init__(self, name, friend=None):
        self.name    = name
        self.friend  = friend

    def say_name(self):
        print("My name is " + self.name)

    def say_goodnight(self):
        if self.friend is None:
            print("Good night nobody.")
        else:
            print("Good night " + self.friend.name)
        #
    #

    # Override the default str() to allow us to print(hunaon_object)
    def __str__(self):
        return(self.name)
    #
#


# Create a new human called Fred
wilma = Human("Wilma")
fred  = Human("Fred", wilma)

fred.name = "Fred"

print("Fred's name is %s\t\t(expect Fred)" % (fred))

#Let's copy 'Fred'
copy_fred = fred

# But let's change his name to Barney
copy_fred.name = 'Barney'

print("Copy of Fred's name %s\t(expect Barney)" % (copy_fred))
print("Copy of Fred's friend %s\t(expect Wilma)" % (copy_fred.friend))
# Good he's now 'Barney'

# Let's check Fred
print("Fred's name %s\t\t(expect Fred)" % (fred))
#'What the ... Fred's now called 'Barney' ?
print("Fred's friend %s\t\t(expect Wilma)" % (fred.friend))

print("\n\tWhat just happened to Fred's name ?!?\n")

print("Okay let's fix that with a new Fred\n-----------------------------------")
fred  = Human("Fred", wilma)
print("Fred's name is %s\t\t(expect Fred)" % (fred))

# Okay let's really copy
betty = copy.deepcopy(fred)
#'Fred'
print("Betty's name %s" % (betty))

print("\nOkay we copied Fred, let's rename to Betty\n")
#'Fred'
betty.name = "Betty"
print("Betty's name %s\t\t(expect Betty)" % (betty))
print("Betty's friend %s\t\t(expect Wilma - copied from Fred)" % (betty.friend))
print("Fred's name is %s\t\t(expect Fred)" % (fred))
print("Fred's friend is %s\t\t(expect Wilma)" % (fred.friend))
