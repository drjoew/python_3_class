#!/bin/python3


class Human(object):
    """Create a Simple human class"""

    def __init__(self, name, friend=None):
        self.name   = name
        self.friend = friend

    def say_name(self):
        print("My name is " + self.name)

    def say_goodnight(self):
        if self.friend is None:
            print("Good night nobody.")
        else:
            print("Good night " + self.friend.name)
        #
    #
#

fred = Human("Fred")
fred.name = "Fred"
#'Fred'

copy_fred = fred
copy_fred.name = 'Barney'
print("Fred's name %s" % (fred.name))
#'Barney'

print("Copy of Fred's name %s" % (copy_fred.name))
#'Barney'
