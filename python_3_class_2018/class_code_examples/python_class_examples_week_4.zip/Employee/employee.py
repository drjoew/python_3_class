#!/bin/python3

# The #number at the end of some of the lines refers to my notes which can also
# be found at the end of this program

import sys #0

class Employee: #1
   """The summary line for a class docstring should fit on one line.

   If the class has public attributes, they may be documented here
   in an "Attributes" section and follow the same formatting as a
   function's "Args" section. Alternatively, attributes may be documented
   inline with the attribute's declaration (see __init__ method below).

   Properties created with the "@property" decorator should be documented
   in the property's getter method.

   Attributes:
       attr1 (str): Description of “attr1".
       attr2 (:obj:`int`, optional): Description of "attr2".

   """ #2
   # These are handles by the __init__
   empCount = 0         # Must be here #3
   # empNumber = 0      # 
   # __secretNumber = 0 # This is like a private variable #4
   #
   def __init__(self, name, salary): #5
      self.name = name #6
      self.salary = salary
      Employee.empCount += 1
      self.empNumber = Employee.empCount
      self.__secretNumber = Employee.empCount
   #
   def displayCount(self): #7
     print("Total Employee %d" % Employee.empCount)
   #
   def displayEmployee(self):
      print("Name : ", self.name,  ", Salary: ", self.salary)
   #
   def displaySecret(self):
      print("Secret = %d" % self.__secretNumber)
   #
   def __str__(self): #8
      return "Name: %s\nSalary: %0.02f\nEmployee number: %d" % (self.name, self.salary, self.empNumber)
   #
#

"""This would create first object of Employee class"""
emp1 = Employee("Zara", 2000) #9 #10
"""This would create second object of Employee class"""
emp2 = Employee("Manni", 5000)

emp1.displayEmployee()
emp2.displayEmployee()
print("Total Employee %d" % Employee.empCount)

print(emp1) #11 (part of the __str__ above)
print(emp2)

print("\nWhat's that __secretNumber?\n===========================")
# Trying to access private data
try: #12 Exceptions
   print("Try #1: %d" % emp1.__secretNumber)
except AttributeError as e:
   print("Try #1: AttributeError as %s" % e)
except:
   print("First try fail: %s" % sys.exc_info[0])
#

# Accessing hidden data or Data not hiding ...
try: #12 cont. #13
   print(emp1._Employee__secretNumber)
   print("Try #2: %d" % emp1._Employee__secretNumber)
except TypeError as e:
   print("Try #2: TypeError as %s" % e)
except:
   print("Try #2: Second try fail: %s" % sys.exc_info[0])
#

"""
Notes:
================================================================================
   - [ ] #0  - Import the sys library for use with exceptions
   - [ ] #1  - Class
   - [ ] #2  - Docstring (demo a docstring)
   - [ ] #3  - Class variable (? & Data )
   - [ ] #4  - Instance variable (and it's a private, more on that later)
   - [ ] #5  - __init__() Constructor
   - [ ] #6  - self.name (need to explain)
   - [ ] #7  - a method
   - [ ] #8  - __str__ (override)
   - [ ] #9  - Instantiate ( Employee("Zara", 2000) creates emp1 )
   - [ ] #10 - Instance ( emp1 is an instance of class Employee)
   - [ ] #11 - using the override
   - [ ] #12 - Trying to access a private variable (throws an exception)
   - [ ] #13 - Trying to access a private variable (so it's not really hidden)
   - [ ] #?  - Inheritance (explained in a later slide)
   - [ ] #?  - Overriding  (explained in a later slide)
   - [ ] #?  - Overloading (function and operator explained in a later slide)
================================================================================
"""
