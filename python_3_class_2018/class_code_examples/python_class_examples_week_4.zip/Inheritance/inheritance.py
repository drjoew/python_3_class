#!/bin/python3

class Parent:        # define parent class
    parentAttr = 100
    def __init__(self):
        self.parentVal = True
        print("Calling parent constructor")

    def parentMethod(self):
        print('Calling parent method')

    def setAttr(self, attr):
        Parent.parentAttr = attr

    def getAttr(self):
        print("Parent attribute :", Parent.parentAttr)

    def __str__(self):
        # Overloading str() via __str__()
        # and even calling the parent method (for good reason than to
        # demonstrate it can be done)
        return("Parent to string and %s" % super().__str__())
#

class Child(Parent): # define child class
    def __init__(self):
        print("Calling child constructor")
        self.childVal = True
        #Parent.__init__(self)
        super().__init__() # pass variable if necessary

    def childMethod(self):
        print('Calling child method')
#

print("Instantiating a new child: c\n")
c = Child()          # instance of child
print("\ndir(c): %s\n" % dir(c))

c.childMethod()      # child calls its method
c.parentMethod()     # calls parent's method
c.setAttr(200)       # again call parent's method
c.getAttr()          # again call parent's method

print("\nparentVal = %d" % c.parentVal)
print("childVal  = %d" % (c.childVal))

print("Child: (%s)" % c)
