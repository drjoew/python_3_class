#!/bin/python3

# A class called Thing - a blueprint
class Thing():                                          # Class
    """DocSting goes here"""                            # docstring
    pass

print("Instantiate object: thing1")
# Instantiate thing1 and thing2
thing1 = Thing()                                        # Instance and Instantiation
# thing1 is now an instance of the Thing() class
print("Instantiate object: thing2")
thing2 = Thing()                                        # Instance and Instantiation

# Let's learn some things about thing1
print("Type info: %s" % (type(thing1)))                 # Now we can do things with thing1
print("dir info: %s\n" % (dir(thing1)))
print(thing1.__doc__)
