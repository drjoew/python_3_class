#this is a comment
i=3 #  this is a line of code followed by a comment
print('This is what a tic-tac-toe symbol looks like #') # the first '#' does not start a comment
