magic_number=73
print ("Sheldon likes magic numbers\nHe wears a T-shirt with the number ", magic_number, " on it")
print ("Another way to express the magic number ", magic_number, "is", "%o"% magic_number, "in octal")
print ("Another way to express the magic number ", magic_number, "is", "%x"% magic_number, "in lower case hexadecimal")
print ("Another way to express the magic number ", magic_number, "is", "%X"% magic_number, "in upper case hexadecimal")
print ("Another way to express the magic number ", magic_number, "is", "{0:b}".format(magic_number), "in binary")
print ("{0:b}".format(magic_number), "is a palindrome\nit reads the same backwards and forwards")
print ("That's why Sheldon likes the number", magic_number)


