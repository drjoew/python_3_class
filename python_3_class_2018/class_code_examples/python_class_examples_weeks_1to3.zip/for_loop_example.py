for i in range(12,20):
    sq_root_i = i**(1.0/2.0)
    print ("for i of",i,"square root of i is", "%5.3f"% sq_root_i)
    
    
