i=10
while i<=120:
    sq_root_i = i**(1.0/2.0)
    print ("for i of","%4.0d"% i,"square root of i is", "%5.3f"% sq_root_i)
    i=i+10
    
    
