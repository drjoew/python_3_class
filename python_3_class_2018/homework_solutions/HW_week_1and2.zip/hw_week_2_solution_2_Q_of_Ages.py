"""
https://medium.com/starts-with-a-bang/ask-ethan-is-the-universe-infinite-or-finite-ec032624dd61 
"""
print("Read the comments to see the web address that answers this question.")
print("The best guess on the answers by Scientists is:")
print("The age of the Universe is 13.8 billion years")
print("From our point-of-view,")
print("we can look back some 46 billion light years in all directions,")
print("thanks to the speed of light and the expansion of space.")
print("Based on experiments from the European Space Angency Planck Satellite")
print("Our best guess is that the radius of the universe is at least")
print(" 250 times the radius that we observe or ")
print("at least 11 trillion light years in all directions is tremendous, but it’s still finite")
print("Scientists do not know this for sure.  This is the best answer that science gives us at this time.")
print("Read the web link in the comments for more information")
